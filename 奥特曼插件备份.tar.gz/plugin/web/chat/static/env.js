envAPIEndpoint="https://api.openai.com/"
envAPIKey="sk-your-token"