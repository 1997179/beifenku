# [rule: ^.*$]
# [cron: 18 12,18,21 * * *]
# [priority: 99999]
# [author: Lxg-021002]
# [version: 1.8.5]
# [class: 工具类]
# [platform: qq,qb,wx,tb,tg,web,wxmp]
# [public: true]
# [open_source: false]
# [price: 5.99]

import sys
import middleware
import requests
import json
from decimal import Decimal
import time
import hashlib
import re
import urllib.parse
import random
from datetime import datetime, timedelta

# [param: {"required":true,"key":"Yzyxmm_elm.zsm","bool":true,"placeholder":"","name":"赞赏码发图或链接","desc":"勾选发图,不勾发链接"}]
# 赞赏码链接
# [param: {"required":true,"key":"Yzyxmm_elm.wx_zsm","bool":false,"placeholder":"必填项,http://xxxx.co/xxx.jpg","name":"收款方式","desc":"Wxbot赞赏码/收款码链接"}]
# 设置青龙容器
# [param: {"required":true,"key":"Yzyxmm_elm.elm_Qinglong","bool":false,"placeholder":"Host丨ClientID丨ClientSecret","name":"设置对接容器","desc":"你的变量需要添加到的容器？参数用丨分割，这个符号是中文的竖(直接复制)"}]
# 乐园币价格
# [param: {"required":true,"key":"Yzyxmm_elm.elm_leyuanmoney","bool":false,"placeholder":"例:0.88,不填为0元","name":"乐园币价格","desc":"乐园币价格(单位:元)"}]
# 饿了么变量名称
# [param: {"required":true,"key":"Yzyxmm_elm.elm_leyuanosname","bool":false,"placeholder":"必填项,例:elmck","name":"乐园币变量名","desc":"青龙容器内乐园币的变量名,默认elmck"}]
# 管理口令
# [param: {"required":true,"key":"Yzyxmm_elm.elm_managecommand","bool":false,"placeholder":"默认:我快饿死了","name":"触发管理的口令","desc":"多个口令用‘丨’分割，这个符号是中文的竖(直接复制)"}]
# 管理口令
# [param: {"required":true,"key":"Yzyxmm_elm.elm_querycommand","bool":false,"placeholder":"默认:吃饱了","name":"触发查询的口令","desc":"多个口令用‘丨’分割，这个符号是中文的竖(直接复制)"}]
# 饿了么需要多少积分一个月
# [param: {"required":true,"key":"Yzyxmm_elm.moneycoin","bool":false,"placeholder":"默认:9999999","name":"乐园币每月积分","desc":"乐园币一个月授权需要多少积分(只能为整数不能为小数)"}]
def getusercontent():
    # 包月价格
    elm_leyuanmoney = middleware.bucketGet(bucket='Yzyxmm_elm', key='elm_leyuanmoney')
    elm_leyuanosname = middleware.bucketGet(bucket='Yzyxmm_elm', key='elm_leyuanosname')
    elm_managecommand = middleware.bucketGet(bucket='Yzyxmm_elm', key='elm_managecommand')
    elm_querycommand = middleware.bucketGet(bucket='Yzyxmm_elm', key='elm_querycommand')
    moneycoin = middleware.bucketGet(bucket='Yzyxmm_elm', key='moneycoin')
    # 收款码链接
    wx_zsm = middleware.bucketGet(bucket='Yzyxmm_elm', key='wx_zsm')
    zsm = middleware.bucketGet(bucket='Yzyxmm_elm', key='zsm')
    if len(elm_leyuanmoney) == 0:
        elm_leyuanmoney = Decimal('0')
    if len(elm_leyuanosname) == 0:
        elm_leyuanosname = 'elmck'
    if len(elm_managecommand) == 0:
        elm_managecommand = '我快饿死了'
    randommanagecommand = elm_managecommand
    if '丨' in elm_managecommand:
        parts = elm_managecommand.split('丨')
        randommanagecommand = random.choice(parts)
    if len(elm_querycommand) == 0:
        elm_querycommand = '吃饱了'
    randomquerycommand = elm_querycommand
    if '丨' in elm_querycommand:
        parts = elm_querycommand.split('丨')
        randomquerycommand = random.choice(parts)
    if len(moneycoin) == 0:
        moneycoin = 9999999
    return zsm, wx_zsm, elm_leyuanmoney, elm_leyuanosname, elm_managecommand, elm_querycommand, moneycoin, randommanagecommand, randomquerycommand



def seekql():
    try:
        ql = middleware.bucketGet(bucket="Yzyxmm_elm", key="elm_Qinglong")
        if len(ql) == 0:
            sender.reply('饿了么插件未填写插件对接的容器，请检查配参')
            exit(0)
        else:
            qllist = ql.split('丨')
            QLurl = qllist[0]
            ClientID = qllist[1]
            ClientSecret = qllist[2]
            qltoken = QLtoken(QLurl=QLurl, ClientID=ClientID, ClientSecret=ClientSecret)
            return QLurl, qltoken
    except Exception:
        sender.reply("获取青龙token失败")
        exit(0)
def delenvs(qlid):
    url = f"{QLurl}/open/envs"
    headers = {
        "Authorization": "Bearer" + ' ' + qltoken,
        "accept": "application/json",
        "Content-Type": "application/json",
    }
    data = [qlid]
    response = requests.delete(url, headers=headers, json=data).json()
    code = response['code']
    if code == 200:
        print('删除成功')


# 获取发送者ID
senderID = middleware.getSenderID()
# 创建发送者
sender = middleware.Sender(senderID)
# 获取发送者QQ号
userid = sender.getUserID()


# 获取用户的值
# uservalue = middleware.bucketGet(bucket, key=userid)


def QLtoken(QLurl, ClientID, ClientSecret):  # 获取青龙token
    try:
        url = f'{QLurl}/open/auth/token?client_id={ClientID}&client_secret={ClientSecret}'
        A = requests.get(url)
        if "token" in A.text:
            ql = A.content
            qlrequests = json.loads(ql)
            qltoken = qlrequests['data']['token']

            return qltoken
        else:
            sender.reply('链接青龙失败,请检查青龙配参！')
            exit(0)
    except Exception:
        sender.reply("链接青龙失败,请检查青龙配参！")
        exit(0)



def QLupdate(osname, value, id, phone):
    phone = phone[:3] + "*" * 4 + phone[7:]
    qlurl = f"{QLurl}/open/envs"
    data = {
        "value": value,
        "name": osname,
        "remarks": f'饿了么管理丨用户:{userid}丨账号:{phone}',
        "id": id
    }
    headers = {
        "Authorization": "Bearer" + ' ' + qltoken,
        "accept": "application/json",
        "Content-Type": "application/json",
    }
    response = requests.put(qlurl, headers=headers, data=json.dumps(data))
    qlurl2 = f"{QLurl}/open/envs/enable"
    data2 = [id]
    response2 = requests.put(qlurl2, headers=headers, json=data2)
    if response.status_code == 200:
        response_json = response.json()
        data = response_json['data']
        if data is None:
            sys.exit()
        qlid = data['id']
        # createdAt = data['createdAt']
        qlurl2 = f"{QLurl}/open/envs/enable"
        return qlid


def QLzt(osname, value, phone):  # 添加青龙变量
    phone = phone[:3] + "*" * 4 + phone[7:]
    try:
        qlurl = f"{QLurl}/open/envs"
        data = [{
            "value": value,
            "name": osname,
            "remarks": f'饿了么管理丨用户:{userid}丨账号:{phone}'
        }]
        headers = {
            "Authorization": "Bearer" + ' ' + qltoken,
            "accept": "application/json",
            "Content-Type": "application/json",
        }
        r = requests.post(qlurl, headers=headers, data=json.dumps(data))
        r_json = r.json()
        if "value must be unique" in r.text:
            return
        else:
            qlid = r_json['data'][0]['id']
            return

        # createdAt = r_json['data'][0]['createdAt']
    except Exception:
        sender.reply("添加青龙变量错误,请联系管理员处理")
        exit(0)


def allenvs(cookie):
    url = f"{QLurl}/open/envs"
    headers = {
        "Authorization": "Bearer" + ' ' + qltoken,
        "accept": "application/json"
    }
    # "Content-Type": "application/json",

    response = requests.get(url, headers=headers).json()
    qlid = None
    if response['code'] == 200:
        envslist = response['data']
        for envs in envslist:
            value = envs['value']
            if value == cookie:
                qlid = envs['id']
                break
        return qlid
    else:
        sender.reply('连接青龙获取变量失败')
        sys.exit()


def userdata(cookie):
    try:
        url = "https://restapi.ele.me/eus/v5/user_detail"

        header = {
            "cookie": cookie,
        }
        data = requests.get(url, headers=header).json()
        account = data['user_id']
        bind = data['mobile']
        username = data['username']
    except Exception:
        account = '查询失败'
        bind = '查询失败'
        username = '查询失败'
    return account, bind, username


def sign(cookie):
    if 'cookie2' in cookie and 'SID' in cookie and 'USERID' in cookie:
        account, bind, username = userdata(cookie)
        bind = bind[:3] + "*" * 4 + bind[7:]
        if account == '查询失败':
            sender.reply('用户信息查询失败,请检查Cookie后重试！')
            sys.exit()
        # 获取绑定的账号
        accounts = middleware.bucketGet(bucket='Yzyxmm_elm_bind', key=userid)
        account_svip = middleware.bucketGet(bucket='Yzyxmm_elm_svip', key=f'{account}')
        if len(accounts) == 0:
            accounts = []
            accounts.append(str(account))
            if len(account_svip) != 0:

                if str(now_time) > account_svip:
                    sender.reply(f'====绑定成功====\n用户:{username}\n用户id:{account}\n手机号:{bind}\n授权已过期')
                else:
                    # acclist = eval(accounts)
                    # 已经被绑定过 更新ck
                    # 取当前id的cookie
                    oldcookie = middleware.bucketGet(bucket='Yzyxmm_elm_account', key=f'{account}')
                    # 更新青龙内的ck
                    qlid = allenvs(oldcookie)
                    if qlid is None:
                        qlid = QLzt(osname=elm_leyuanosname, value=cookie, phone=bind)
                    else:
                        qlid = QLupdate(osname=elm_leyuanosname, value=cookie, id=qlid, phone=bind)
                    sender.reply(f'🧑‍🦱手机号:{bind}绑定Cookie成功！发送“{randommanagecommand}”进行管理！')
            else:
                sender.reply(f'🧑‍🦱手机号:{bind}绑定饿了么Cookie成功！发送“{randommanagecommand}”进行管理！')
            middleware.bucketSet(bucket='Yzyxmm_elm_bind', key=userid, value=f'{accounts}')
            middleware.bucketSet(bucket='Yzyxmm_elm_account', key=f'{account}', value=f'{cookie}')
            middleware.bucketSet(bucket='Yzyxmm_elm_phone', key=f'{account}', value=f'{bind}')

        elif str(account) in accounts:
            # 已经绑定这个账号
            # 取当前id的cookie
            oldcookie = middleware.bucketGet(bucket='Yzyxmm_elm_account', key=f'{account}')
            if len(account_svip) != 0:
                if str(now_time) > account_svip:
                    middleware.bucketSet(bucket='Yzyxmm_elm_account', key=f'{account}', value=f'{cookie}')
                    middleware.bucketSet(bucket='Yzyxmm_elm_phone', key=f'{account}', value=f'{bind}')
                    accounts = []
                    accounts.append(str(account))
                    middleware.bucketSet(bucket='Yzyxmm_elm_bind', key=userid, value=f'{accounts}')
                    sender.reply(f'🧑‍🦱手机号:{bind}，当前账号授权已过期，快发送‘{randommanagecommand}’进行续期吧！')
                else:
                    # 更新青龙内的ck
                    qlid = allenvs(oldcookie)
                    if qlid is None:
                        qlid = QLzt(osname=elm_leyuanosname, value=cookie, phone=bind)
                        middleware.bucketSet(bucket='Yzyxmm_elm_account', key=f'{account}', value=f'{cookie}')
                        middleware.bucketSet(bucket='Yzyxmm_elm_phone', key=f'{account}', value=f'{bind}')
                        sender.reply(f'🧑‍🦱手机号:{bind}更新Cookie成功！')
                    else:
                        qlid = QLupdate(osname=elm_leyuanosname, value=cookie, id=qlid, phone=bind)
                        middleware.bucketSet(bucket='Yzyxmm_elm_account', key=f'{account}', value=f'{cookie}')
                        middleware.bucketSet(bucket='Yzyxmm_elm_phone', key=f'{account}', value=f'{bind}')
                        sender.reply(f'🧑‍🦱手机号:{bind}更新Cookie成功！')
            else:
                middleware.bucketSet(bucket='Yzyxmm_elm_account', key=f'{account}', value=f'{cookie}')
                middleware.bucketSet(bucket='Yzyxmm_elm_phone', key=f'{account}', value=f'{bind}')
                sender.reply(f'🧑‍🦱手机号:{bind}更新Cookie成功！当前账号未授权，快发送‘{randommanagecommand}’进行授权吧！')
        else:
            acclist = eval(accounts)
            middleware.bucketSet(bucket='Yzyxmm_elm_phone', key=f'{account}', value=f'{bind}')
            # 把新添加账号添加到已经绑定的账号里面
            acclist.append(str(account))
            # 先获取旧的ck
            oldcookie = middleware.bucketGet(bucket='Yzyxmm_elm_account', key='account')
            # 添加账号数据
            middleware.bucketSet(bucket='Yzyxmm_elm_account', key=f'{account}', value=f'{cookie}')
            middleware.bucketSet(bucket='Yzyxmm_elm_bind', key=userid, value=f'{acclist}')
            if len(account_svip) == 0 or str(now_time) > account_svip:

                sender.reply(f'🧑‍🦱手机号:{bind},绑定成功！快发送‘{randommanagecommand}’管理账号吧！该账号未授权！')
            else:
                # 账号已经授权添加或者更新变量
                qlid = allenvs(cookie=cookie)
                if qlid is None:
                    qlid = QLzt(osname=elm_leyuanosname, value=oldcookie, phone=bind)
                else:
                    qlid = QLupdate(osname=elm_leyuanosname, value=cookie, id=qlid, phone=bind)
                sender.reply(f'🧑‍🦱手机号:{bind},Cookie更新成功！快发送{randommanagecommand}管理账号吧！')
                # 这个账号被绑定过, 更新ck
                # middleware.bucketSet(bucket='Yzyxmm_elm_account', key=f'{account}', value=f'{cookie}')

    else:
        sys.exit()


def manage():
    # 获取绑定的所有账号
    accounts = middleware.bucketGet(bucket='Yzyxmm_elm_bind', key=userid)
    message = ''
    count = 1
    if len(accounts) != 0:
        acclist = eval(accounts)
        for accid in acclist:
            cookie = middleware.bucketGet(bucket='Yzyxmm_elm_account', key=accid)
            accsvip = middleware.bucketGet(bucket='Yzyxmm_elm_svip', key=accid)
            bind = middleware.bucketGet(bucket='Yzyxmm_elm_phone', key=f'{accid}')
            if len(accsvip) == 0:
                accsvip = '未授权'
            elif accsvip < str(now_time):
                accsvip = '授权过期'
            account, binds, username = userdata(cookie)
            if account == '查询失败':
                account = 'Cookie过期'
            bind = bind[:3] + "*" * 4 + bind[7:]
            message += f'[{count}]-----\n📱手机号:{bind}\n🪪用户ID:{account}\n☁️云授权:{accsvip}\n'
            count = count + 1
        message_to_send = f"=====我的饿了么=====\n乐园币:{elm_leyuanmoney}元/月\n{message}"
        sender.reply(message_to_send)
        sender.reply('请选择[]内的数字对账号进行管理，回复[q]退出')
        mations = sender.input(120000, 1, False)
        if mations == 'q':
            sender.reply('退出！')
            sys.exit()
        elif mations == 'timeout':
            sender.reply('超时,退出！')
            sys.exit()
        else:
            try:
                mation_int = int(mations)
                mation_int = mation_int - 1
                account = acclist[mation_int]
                cookie = middleware.bucketGet(bucket='Yzyxmm_elm_account', key=f'{account}')
                accsvip = middleware.bucketGet(bucket='Yzyxmm_elm_svip', key=f'{account}')
                bind = middleware.bucketGet(bucket='Yzyxmm_elm_phone', key=f'{account}')
                if len(accsvip) == 0:
                    accsvip = '未授权'
                elif accsvip < str(now_time):
                    accsvip = '授权过期'
                account, binds, username = userdata(cookie)
                if account == '查询失败':
                    account = 'Cookie过期'
                    username = 'Cookie过期'
                bind = bind[:3] + "*" * 4 + bind[7:]
                sender.reply(f'\n🧑‍🦱用户名:{username}\n🪪用户ID:{account}\n📱手机:{bind}\n☁️云授权:{accsvip}\n')
                sender.reply('[1]开通乐园币\n[2]删除账号\n[q]退出')
                mation = sender.input(120000, 1, False)
                if mation == '1':
                    # 开通乐园币
                    sender.reply('请输入需要的月数,例: 1')
                    mation = sender.input(120000, 1, False)
                    try:
                        mation_int = int(mation)
                        money = Decimal(mation) * Decimal(elm_leyuanmoney)
                        if money == Decimal('0'):
                            empower(empowertime=accsvip, account=account, cookie=cookie, mation_int=mation_int, phone=bind)
                        else:
                            Pointpayment(mation_int, accsvip, cookie, account,bind)
                            zf(money=money, osname=elm_leyuanosname, mation_int=mation_int)
                            empower(empowertime=accsvip, account=account, cookie=cookie, mation_int=mation_int, phone=bind)
                        sender.reply(
                            f'=====订单完成=====\n💎名称:乐园币\n🔢数量:{mation_int}月\n💶支付金额:{money}元')
                    except ValueError:
                        sender.reply('输入错误')
                elif mation == '2':
                    sender.reply(
                        '请确认是否删除该账号？账号删除后同授权时间会一同删除，这条信息将会通知管理员处理\n[y]确认丨[n]退出')
                    mation = sender.input(120000, 1, False)
                    if mation == 'y':
                        acclist.remove(f'{account}')
                        # 寻找青龙变量
                        qlid = allenvs(cookie=cookie)
                        delenvs(qlid=qlid)
                        if len(acclist) == 0:
                            middleware.bucketDel(bucket='Yzyxmm_elm_bind', key=userid)
                        else:
                            middleware.bucketSet(bucket='Yzyxmm_elm_bind', key=userid, value=f'{acclist}')
                        middleware.bucketDel(bucket='Yzyxmm_elm_account', key=f'{account}')
                        accvip = middleware.bucketDel(bucket='Yzyxmm_elm_vip', key=f'{account}')
                        accsvip = middleware.bucketDel(bucket='Yzyxmm_elm_svip', key=f'{account}')
                        middleware.notifyMasters(
                            content=f'用户:{userid}来自:{imtype}删除了一个账号，请您进行联系下一步的处理',
                            imtypes=['wb', 'tg', 'qb', 'qq'])
                        sender.reply('账号删除成功，并且已经告知管理员！')
                    elif mation == 'n':
                        sender.reply('退出！')
                    else:
                        sender.reply('输入错误')
                elif mation == 'q':
                    sender.reply('退出！')
                else:
                    sender.reply('输入错误！')
            except ValueError:
                sender.reply('输入错误')
    else:
        sender.reply('暂未绑定饿了么账号，请获取Cookie后直接发给我！')


def Pointpayment(mation_int, accsvip, cookie, account, bind):
    usercoin = middleware.bucketGet(bucket='Yzyxmm_sign_coin', key=f'{userid}')
    if len(usercoin) != 0 and usercoin != '0':
        zfcoin = int(moneycoin) * mation_int
        if int(usercoin) >= int(zfcoin):
            sender.reply(f'当前积分{usercoin}积分，订单所需{zfcoin}积分是否使用积分进行抵扣？')
            sender.reply('[y]是丨[n]否')
            yesorno = sender.input(120000, 1, False)
            if yesorno == 'Y' or yesorno == 'y' or yesorno == '是':
                usercoin = int(usercoin) - int(zfcoin)
                middleware.bucketSet(bucket='Yzyxmm_sign_coin', key=f'{userid}',
                                     value=f'{usercoin}')
                empower(empowertime=accsvip, account=account, cookie=cookie, mation_int=mation_int, phone=bind)
                sender.reply(f'=====订单完成=====\n💎名称:乐园币\n🔢数量:{mation_int}月\n💶支付金额:{zfcoin}积分')
                exit(0)
            elif yesorno == 'n' or yesorno == 'N' or yesorno == '否':
                # 不使用积分抵扣
                return


def empower(empowertime, account, cookie, mation_int, phone):
    day = mation_int * 30
    qlid = QLzt(osname=elm_leyuanosname, value=cookie, phone=phone)
    if empowertime == '授权过期' or empowertime == '未授权' or empowertime <= str(now_time):
        # 将当前时间延后
        new_time = now_time + timedelta(days=day)
        #new_time = current_time.shift(months=mation_int)
        #formatted_new_time = new_time.format("YYYY-MM-DD")
        middleware.bucketSet(bucket='Yzyxmm_elm_svip', key=f'{account}',
                             value=str(new_time))
    elif empowertime > str(now_time):
        empower_date = datetime.strptime(empowertime, "%Y-%m-%d")
        delayed_date = empower_date + timedelta(days=day)
        new_time = delayed_date.date()
        middleware.bucketSet(bucket='Yzyxmm_elm_svip', key=f'{account}',
                             value=str(new_time))
    else:
        sender.reply('出错')
        sys.exit()


def zf(money, osname, mation_int):  # 等待支付并且发送ck到青龙、
    zfzt = sender.atWaitPay()
    if zfzt != True:
        if osname == elm_leyuanosname:
            sender.reply(f'=====订单结算=====\n💎名称:乐园币\n🔢数量:{mation_int}月\n💶应付:{money}元')
            '''        if osname == Meituan_os_tbname:
            sender.reply(f'=====订单结算=====\n💎名称:团币\n🔢数量:{me_as_int}月\n💶应付:{money}元')'''
        if zsm == 'true':
            sender.replyImage(wx_zsm)
        else:
            sender.reply(f'支付链接:{wx_zsm}')
        # 等待支付120秒
        ddzf = sender.waitPay("q", 120 * 1000)
        if str(ddzf) == 'q':
            sender.reply('退出支付')
            sys.exit()
        if 'Time' in str(ddzf):
            try:
                zfjson = json.loads(ddzf)
                zfmoney = zfjson['Money']
            except Exception:
                zfmoney = ddzf['Money']
            if int(zfmoney) == int(money):
                # sender.reply('支付金额正确')
                return
            else:
                sender.reply(f'支付金额错误\n应付:{money}元\n实付:{zfmoney}元\n请联系管理员处理退款！')
                sys.exit()
        elif ddzf == 'timeout':
            sender.reply('支付超时！')
            sys.exit()
    else:
        sender.reply('当前有人正在支付,请稍后再试！')
        sys.exit()


def signs(mh5tk, ts, data):
    # data = {"templateIds": "[\"1404\"]"}
    data_str = json.dumps(data, separators=(',', ':'))

    e = mh5tk + "&" + ts + "&" + '12574478' + "&" + data_str
    sign = hashlib.md5(e.encode()).hexdigest()
    return sign


def cx(cookie):
    def res(header, cookie):
        str_header = str(header)
        mh5tk = re.search(r'_m_h5_tk=([^_]+)', str_header).group(1)
        regex1 = r'_m_h5_tk=[0-9a-f]+_[0-9]+;'
        regex2 = r'_m_h5_tk_enc=[0-9a-f]+;'
        str1 = re.search(regex1, str_header).group(0)
        str2 = re.search(regex2, str_header).group(0)
        cookie = re.sub(r'_m_h5_tk=[^;]+;?', '', cookie)
        cookie = re.sub(r'_m_h5_tk_enc=[^;]+;?', '', cookie)
        cookie = str1 + str2 + cookie
        return cookie, mh5tk

    def eatapi(cookie):
        try:
            todayeat = 0
            url = 'https://h5.ele.me/restapi/svip_biz/v1/supervip/foodie/records?offset=0&limit=100&longitude=116.397128&latitude=39.916527'
            headers = {
                "cookie": cookie,
            }
            respnse = requests.get(url=url, headers=headers)
            if '未登录' in respnse.text:
                eatcount = '查询失败'
            else:

                eat = respnse.json()
                eatcount = eat['peaCount']
                records = eat['records']
                if records is None:
                    return eatcount, '0'
                for eats in records:
                    createdTime = eats['createdTime']
                    datetime_obj = datetime.strptime(createdTime, "%Y-%m-%d %H:%M:%S")
                    recordtime = datetime_obj.strftime("%Y-%m-%d")
                    if recordtime < str(now_time):
                        break
                    else:
                        count = eats['count']
                        optType = eats['optType']
                        if optType == 2:
                            continue
                        else:
                            todayeat = todayeat + int(count)

            return eatcount, todayeat
        except Exception as e:
            return '查询错误', '查询错误'

    def bbf(cookie):
        try:
            url = 'https://wallet.ele.me/api/storedcard/queryBalanceBycardType?cardType=platform'
            headers = {
                "cookie": cookie,
            }
            respnse = requests.get(url=url, headers=headers)
            if '未登录' in respnse.text or '成功' not in respnse.text:
                money = '查询失败'
            else:
                wallet = respnse.json()
                money = wallet['data']['totalAvailableAmount'] / 100
            return money
        except Exception:
            return '查询错误'

    def todayreques(cookie):
        try:
            pageNo = 1
            retrynum = 0
            todayleyuanB = 0
            mh5tk = 'a8b654ea8b2d8897556edb7eed592e4e'
            while True:
                ts = str(time.time() * 1000)
                data = {"templateId": "1404", "bizScene": "game_center", "convertType": "GAME_CENTER",
                        "startTime": "2023-1-5 00:00:00", "pageNo": str(pageNo), "pageSize": "100"}
                sign = signs(mh5tk, ts, data)
                url = f'https://mtop.ele.me/h5/mtop.koubei.interaction.center.common.querypropertydetail/1.0/5.0/?jsv=2.7.0&appKey=12574478&t={ts}&sign={sign}&api=mtop.koubei.interaction.center.common.querypropertydetail&v=1.0&ecode=1&type=json&valueType=string&needLogin=true&LoginRequest=true&dataType=jsonp'
                headers = {
                    "Host": "mtop.ele.me",
                    "Accept": "application/json",
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36",
                    "Content-type": "application/x-www-form-urlencoded;charset=UTF-8",
                    "Origin": "https://tb.ele.me",
                    "Referer": "https://tb.ele.me/",
                    "Accept-Language": "zh-CN,zh-Hans;q=0.9",
                    "x-ele-check-client": "ele",
                    "Content-Length": "214",
                    "Connection": "keep-alive",
                    "Cookie": cookie
                }
                data = f'{{"templateId":"1404","bizScene":"game_center","convertType":"GAME_CENTER","startTime":"2023-1-5 00:00:00","pageNo":"{pageNo}","pageSize":"100"}}'
                # 对字符串进行URL编码
                encoded_string = urllib.parse.quote(data, safe='')
                response = requests.post(url, headers=headers, data=f'data={encoded_string}')
                if '调用成功' in response.text:
                    tleyuan = response.json()
                    list = tleyuan['data']['list']
                    if len(list) == 0:
                        return todayleyuanB
                    for details in list:
                        gmtModifiedStr = details['gmtModifiedStr']
                        datetime_obj = datetime.strptime(gmtModifiedStr, "%Y-%m-%d %H:%M:%S")
                        recordtime = datetime_obj.strftime("%Y-%m-%d")
                        if recordtime < str(now_time):
                            return todayleyuanB
                        else:
                            amount = details['amount']
                        detailType = details['detailType']
                        if detailType == 'REDUCE':
                            continue
                        else:
                            todayleyuanB = todayleyuanB + int(amount)
                    detailss = list[-1]
                    gmtModifiedStr = detailss['gmtModifiedStr']
                    datetime_obj = datetime.strptime(gmtModifiedStr, "%Y-%m-%d %H:%M:%S")
                    recordtime = datetime_obj.strftime("%Y-%m-%d")
                    if recordtime < str(now_time):
                        return todayleyuanB
                    else:
                        pageNo = pageNo + 1
                        continue

                else:
                    if retrynum == 2:
                        sys.exit()
                    retrynum = retrynum + 1
                    header = response.headers
                    cookie, mh5tk = res(header, cookie)
        except Exception:
            return '查询错误'

    def leyuanB(cookie):
        try:
            mh5tk = 'a8b654ea8b2d8897556edb7eed592e4e'
            count = '查询失败'
            money = '查询失败'
            todayleyuanB = 0
            for _ in range(2):
                ts = str(time.time() * 1000)
                data = {"templateIds": "[\"1404\"]"}
                sign = signs(mh5tk, ts, data)
                url = f'https://mtop.ele.me/h5/mtop.koubei.interaction.center.common.queryintegralproperty.v2/1.0/?jsv=2.7.0&appKey=12574478&t={ts}&sign={sign}&api=mtop.koubei.interaction.center.common.queryintegralproperty.v2&v=1.0&ecode=1&type=json&valueType=string&needLogin=true&LoginRequest=true&dataType=jsonp'
                headers = {
                    "Host": "mtop.ele.me",
                    "Accept": "application/json",
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36",
                    "Content-type": "application/x-www-form-urlencoded",
                    "Origin": "https://tb.ele.me",
                    "Sec-Fetch-Site": "same-site",
                    "Sec-Fetch-Mode": "cors",
                    "Sec-Fetch-Dest": "empty",
                    "Referer": "https://tb.ele.me/wow/alsc/mod/3fe8408d9ba38d4726448a87?spm-pre=a2ogi.bx828379.0.0&spm=a13.b_activity_kb_m69301.0.0",
                    "Accept-Encoding": "gzip, deflate, br",
                    "Accept-Language": "zh-CN,zh;q=0.9",
                    "Cookie": cookie,
                }
                data = "data=%7B%22templateIds%22%3A%22%5B%5C%221404%5C%22%5D%22%7D"
                response = requests.post(url, headers=headers, data=data)
                if '调用成功' in response.text:
                    leyuan = response.json()
                    count = leyuan['data']['data']['1404']['count']
                    money = bbf(cookie)
                    eatcount, todayeat = eatapi(cookie)
                    return count, money, eatcount, todayeat

                else:
                    header = response.headers
                    cookie, mh5tk = res(header, cookie)
        except Exception:
            return '查询错误', '查询错误', '查询错误', '查询错误'

    count, money, eatcount, todayeat = leyuanB(cookie)
    todayleyuanB = todayreques(cookie)
    return count, money, eatcount, todayeat, todayleyuanB

now_time = datetime.now().date()
QLurl, qltoken = seekql()
zsm, wx_zsm, elm_leyuanmoney, elm_leyuanosname, elm_managecommand, elm_querycommand, moneycoin, randommanagecommand, randomquerycommand = getusercontent()
imtype = sender.getImtype()
#KM = middleware.bucketAllKeys(bucket='Yzyxmm_Cami_coin')
# 获取用户触发的消息
usermessage = sender.getMessage()
if usermessage == '':
    usermessage = '1'
messageID = sender.getMessageID()
if 'cookie2' in usermessage and 'SID' in usermessage and 'USERID' in usermessage:
    #A = sender.recallMessage(messageID)
    sign(usermessage)
elif any(usermessage == s for s in elm_managecommand.split('丨')):
    manage()
elif any(usermessage == s for s in elm_querycommand.split('丨')):
    # 获取绑定的所有账号
    accounts = middleware.bucketGet(bucket='Yzyxmm_elm_bind', key=userid)
    message = ''
    count = 1
    if len(accounts) != 0:
        acclist = eval(accounts)
        if len(acclist) == 1:
            sender.reply('正在获取数据....')
            account = acclist[0]
            cookie = middleware.bucketGet(bucket='Yzyxmm_elm_account', key=account)
            accsvip = middleware.bucketGet(bucket='Yzyxmm_elm_svip', key=account)
            bind = middleware.bucketGet(bucket='Yzyxmm_elm_phone', key=f'{account}')
            if len(accsvip) == 0:
                count = accsvip = '未授权'
            elif accsvip < str(now_time):
                count = accsvip = '云授权过期'
            account2, bind, username = userdata(cookie)
            if account2 == '查询失败':
                bind = middleware.bucketGet(bucket='Yzyxmm_elm_phone', key=f'{account}')
                bind = bind[:3] + "*" * 4 + bind[7:]
                sender.reply(
                    f'【{bind}】账号Cookie过期')
            else:
                if accsvip != '未授权' and accsvip != '云授权过期':
                    count, money, eatcount, todayeat, todayleyuanB = cx(cookie)
                    bind = bind[:3] + "*" * 4 + bind[7:]
                    sender.reply(
                        f'📱手机号:{bind}\n🪪用户ID:{account}\n🛒今日乐园币:{todayleyuanB}\n🎮乐园币:{count}\n🪧今日吃货豆:{todayeat}\n⚙饿了吃货豆:{eatcount}\n💰笔笔返余额:{money}\n☁️云授权:{accsvip}')
                else:
                    bind = bind[:3] + "*" * 4 + bind[7:]
                    sender.reply(
                        f'【{bind}】账号{accsvip}')
        else:
            for accid in acclist:
                cookie = middleware.bucketGet(bucket='Yzyxmm_elm_account', key=accid)
                accsvip = middleware.bucketGet(bucket='Yzyxmm_elm_svip', key=accid)
                bind = middleware.bucketGet(bucket='Yzyxmm_elm_phone', key=f'{accid}')
                if len(accsvip) == 0:
                    accsvip = '未授权'
                elif accsvip < str(now_time):
                    accsvip = '授权过期'
                account, binds, username = userdata(cookie)
                if account == '查询失败':
                    account = 'Cookie过期'
                bind = bind[:3] + "*" * 4 + bind[7:]
                message += f'[{count}]-----\n📱手机号:{bind}\n🪪用户ID:{account}\n☁️云授权:{accsvip}\n'
                count = count + 1
            message_to_send = f"=====查询饿了么=====\n[0]全部账号\n{message}\n"
            sender.reply(message_to_send)
            sender.reply('请选择[]内的数字对账号进行查询，回复[q]退出')
            mations = sender.input(120000, 1, False)
            if mations == '0':
                sender.reply('正在获取数据....')
                acclist = eval(accounts)
                for account in acclist:
                    cookie = middleware.bucketGet(bucket='Yzyxmm_elm_account', key=f'{account}')
                    accsvip = middleware.bucketGet(bucket='Yzyxmm_elm_svip', key=f'{account}')
                    count = '查询失败'
                    eatcount = '查询失败'
                    money = '查询失败'
                    todayeat = '查询失败'
                    todayleyuanB = '查询失败'
                    if len(accsvip) == 0:
                        count = accsvip = '未授权'
                    elif accsvip < str(now_time):
                        count = accsvip = '云授权过期'
                    account2, bind, username = userdata(cookie)
                    if account2 == '查询失败':
                        bind = middleware.bucketGet(bucket='Yzyxmm_elm_phone', key=f'{account}')
                        bind = bind[:3] + "*" * 4 + bind[7:]
                        sender.reply(
                            f'【{bind}】账号Cookie过期')
                    else:
                        if accsvip != '未授权' and accsvip != '云授权过期':
                            count, money, eatcount, todayeat, todayleyuanB = cx(cookie)
                            bind = bind[:3] + "*" * 4 + bind[7:]
                            sender.reply(
                                f'📱手机号:{bind}\n🪪用户ID:{account}\n🛒今日乐园币:{todayleyuanB}\n🎮乐园币:{count}\n🪧今日吃货豆:{todayeat}\n⚙饿了吃货豆:{eatcount}\n💰笔笔返余额:{money}\n☁️云授权:{accsvip}')
                        else:
                            bind = bind[:3] + "*" * 4 + bind[7:]
                            sender.reply(
                                f'【{bind}】账号{accsvip}')
            else:
                try:
                    mation_int = int(mations)
                    mation_int = mation_int - 1
                    account = acclist[mation_int]
                    cookie = middleware.bucketGet(bucket='Yzyxmm_elm_account', key=account)
                    accsvip = middleware.bucketGet(bucket='Yzyxmm_elm_svip', key=account)
                    bind = middleware.bucketGet(bucket='Yzyxmm_elm_phone', key=f'{account}')
                    if len(accsvip) == 0:
                        count = accsvip = '未授权'
                    elif accsvip < str(now_time):
                        count = accsvip = '云授权过期'
                    account2, bind, username = userdata(cookie)
                    if account2 == '查询失败':
                        bind = middleware.bucketGet(bucket='Yzyxmm_elm_phone', key=f'{account}')
                        bind = bind[:3] + "*" * 4 + bind[7:]
                        sender.reply(
                            f'【{bind}】账号Cookie过期')
                    else:
                        if accsvip != '未授权' and accsvip != '云授权过期':
                            count, money, eatcount, todayeat, todayleyuanB = cx(cookie)
                            bind = bind[:3] + "*" * 4 + bind[7:]
                            sender.reply(
                                f'📱手机号:{bind}\n🪪用户ID:{account}\n🛒今日乐园币:{todayleyuanB}\n🎮乐园币:{count}\n🪧今日吃货豆:{todayeat}\n⚙饿了吃货豆:{eatcount}\n💰笔笔返余额:{money}\n☁️云授权:{accsvip}')
                        else:
                            bind = bind[:3] + "*" * 4 + bind[7:]
                            sender.reply(
                                f'【{bind}】账号{accsvip}')
                except ValueError:
                    sender.reply('输入错误！')
    else:
        sender.reply('未绑定饿了么账号，请获取Cookie后直接发给我！')
elif imtype == 'fake':
    bindlist = middleware.bucketAllKeys(bucket='Yzyxmm_elm_bind')
    for user in bindlist:
        accouts = middleware.bucketGet(bucket='Yzyxmm_elm_bind', key=f'{user}')
        accoutlist = eval(accouts)
        for useraccount in accoutlist:
            cookie = middleware.bucketGet(bucket='Yzyxmm_elm_account', key=f'{useraccount}')
            phone = middleware.bucketGet(bucket='Yzyxmm_elm_phone', key=f'{useraccount}')
            empower = middleware.bucketGet(bucket='Yzyxmm_elm_svip', key=f'{useraccount}')
            account, bind, username = userdata(cookie)
            if '查询失败' in bind:
                middleware.push('wb', '', user, '',
                                f'📱手机号‘{phone}’，饿了么Cookie已过期,请及时更新！')
                middleware.push('tg', '', user, '',
                                f'📱手机号‘{phone}’，饿了么Cookie已过期,请及时更新！')
                middleware.push('qb', '', user, '',
                                f'📱手机号‘{phone}’，饿了么Cookie已过期,请及时更新！')
                middleware.push('qq', '', user, '',
                                f'📱手机号‘{phone}’，饿了么Cookie已过期,请及时更新！')
            if len(empower) == 0:
                middleware.push('wb', '', user, '',
                                f'📱手机号‘{phone}’，饿了么授权还未开通,可发送‘{randommanagecommand}’进行授权！')
                middleware.push('tg', '', user, '',
                                f'📱手机号‘{phone}’，饿了么授权还未开通,可发送‘{randommanagecommand}’进行授权！')
                middleware.push('qb', '', user, '',
                                f'📱手机号‘{phone}’，饿了么授权还未开通,可发送‘{randommanagecommand}’进行授权！')
                middleware.push('qq', '', user, '',
                                f'📱手机号‘{phone}’，饿了么授权还未开通,可发送‘{randommanagecommand}’进行授权！')
            elif str(now_time) > empower:
                middleware.push('wb', '', user, '',
                                f'📱手机号‘{phone}’，饿了么授权已过期,可发送‘{randommanagecommand}’进行授权！')
                middleware.push('tg', '', user, '',
                                f'📱手机号‘{phone}’，饿了么授权已过期,可发送‘{randommanagecommand}’进行授权！')
                middleware.push('qb', '', user, '',
                                f'📱手机号‘{phone}’，饿了么授权已过期,可发送‘{randommanagecommand}’进行授权！')
                middleware.push('qq', '', user, '',
                                f'📱手机号‘{phone}’，饿了么授权已过期,可发送‘{randommanagecommand}’进行授权！')
else:
    sender.setContinue()
