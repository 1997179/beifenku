#!/bin/bash
# 系统需要安装jq
# 网络访问请求函数
# 参数:
#   $1: URL
#   $2: 超时时间（秒）
function make_request() {
    local url="http://localhost:8080/otto$1"
    local body=$2
    local timeout=$3

    # 发送GET请求，并设置超时时间
    if response=$(curl -X POST -H 'Content-Type: application/json' -s -m "$timeout" "$url" -d "$body"); then
        # 解析响应
        data=$(echo "$response" | jq -r ".data")
        # 打印响应
        echo "$data"
    else
        echo ""
    fi
}

# 添加消息监听及回调
function addMsgListener() {
    local url="http://localhost:8080/otto/msghook"
    local imtype=$1
    local chatid=$2
    local userid=$3
    #将上面的参数转为json格式
    local json_data='{"imtype":"'$imtype'","chatid":"'$chatid'","userid":"'$userid'"}'
    local callback_func="$4"

    curl -X POST "$url" \
        --header "Content-Type: application/json" \
        --data "$json_data" \
        --no-buffer \
        --silent \
        | while read -r line; do
            $callback_func "$line"
        done
}

# 推送消息
function push(){
    local imType=$1
    local groupcode=$2
    local userid=$3
    local title=$4
    local content=$5

    local url="/push"
    local body='{"imType":"'$imType'","groupCode":'$groupcode',"userID":"'$userid'","title":"'$title'","content":"'$content'"}'
    make_request "$url" "$body" 5000
}

# 获取机器人名称
function name(){
    local url="/name"
    local body=''
    make_request "$url" "$body" 5000
}

# 获取机器id
function machineId(){
    local url="/machineId"
    local body=''
    make_request "$url" "$body" 5000
}

# 获取机器人版本
function version(){
    local url="/version"
    local body=''
    make_request "$url" "$body" 5000
}

# 获取数据库数据
function get(){
    local key=$1
    local url="/get"
    local body='{"key":"'$key'"}'
    make_request "$url" "$body" 5000
}

# 设置数据库数据
function set(){
    local key=$1
    local value=$2
    local url="/set"
    local body='{"key:'$key'","value:'$value'"}'
    make_request "$url" "$body" 5000
}

# 删除数据库数据
function del(){
    local key=$1
    local url="/del"
    local body='{"key":"'$key'"}'
    make_request "$url" "$body" 5000
}

# 获取指定数据库指定的key值
function bucketGet(){
    local bucket=$1
    local key=$2
    local url="/bucket/get"
    local body='{"bucket":"'$bucket'","key":"'$key'"}'
    make_request "$url" "$body" 5000
}

# 设置指定数据库指定的key值
function bucketSet(){
    local bucket=$1
    local key=$2
    local value=$3
    local url="/bucket/set"
    local body='{"bucket":"'$bucket'","key":"'$key'","value":"'$value'"}'
    make_request "$url" "$body" 5000
}

# 删除指定数据库指定的key值
function bucketDel(){
    local bucket=$1
    local key=$2
    local url="/bucketDel"
    local body='{"bucket":"'$bucket'","key":"'$key'"}'
    make_request "$url" "$body" 5000
}

# 获取指定数据库的所有值为value的keys
function bucketKeys(){
    local bucket=$1
    local value=$2
    local url="/bucket/keys"
    local body='{"bucket":"'$bucket'","value":"'$value'"}'
    make_request "$url" "$body" 5000
}

# 获取指定数据库的所有key
function bucketAllKeys(){
    local bucket=$1
    local url="/bucketAllKeys"
    local body='{"bucket":"'$bucket'"}'
    make_request "$url" "$body" 5000
}

# 通知管理员
function notifyMasters(){
    local content=$2
    local imtypes=$3
    local url="/notifyMasters"
    local body='{"content":"'$content'","imtypes":"'$imtypes'"}'
    make_request "$url" "$body" 5000
}

# 系统授权状态
function coffee(){
    local url="/coffee"
    local body=''
    make_request "$url" "$body" 5000
}

# 京东、淘宝、拼多多转链推广
function spread(){
    local msg=$1
    local url="/spread"
    local body='{"msg":"'$msg'"}'
    make_request "$url" "$body" 5000
}

declare -A sender
# 设置变量
sender[senderid]="senderid"

# 获取指定数据库指定的key值
sender.bucketGet(){
    local bucket=$1
    local key=$2
    local url="/bucket/get"
    local body='{"senderid":"'${sender[senderid]}'","bucket":"'$bucket'","key":"'$key'"}'
    make_request "$url" "$body" 5000
}

# 设置指定数据库指定的key值
sender.bucketSet(){
    local bucket=$1
    local key=$2
    local value=$3
    local url="/bucket/set"
    local body='{"senderid":"'${sender[senderid]}'","bucket":"'$bucket'","key":"'$key'","value":"'$value'"}'
    make_request "$url" "$body" 5000
}

# 删除指定数据库指定的key值
sender.bucketDel(){
    local bucket=$1
    local key=$2
    local url="/bucketDel"
    local body='{"senderid":"'${sender[senderid]}'","bucket":"'$bucket'","key":"'$key'"}'
    make_request "$url" "$body" 5000
}

# 获取指定数据库的所有值为value的keys
sender.bucketKeys(){
    local bucket=$1
    local value=$2
    local url="/bucket/keys"
    local body='{"senderid":"'${sender[senderid]}'","bucket":"'$bucket'","value":"'$value'"}'
    make_request "$url" "$body" 5000
}

# 获取指定数据库的所有key
sender.bucketAllKeys(){
    local bucket=$1
    local url="/bucketAllKeys"
    local body='{"senderid":"'${sender[senderid]}'","bucket":"'$bucket'"}'
    make_request "$url" "$body" 5000
}

# 设置关键词继续向下匹配其它优先级低的插件
sender.setContinue() {
    local url="/continue"
    local body='{"senderid":"'${sender[senderid]}'"}'
    make_request "$url" "$body" 5000
}

# 获取路由路径
sender.getRoutePath() {
    local url= "/getRoutePath"
    local body='{"senderid":"'${sender[senderid]}'"}'
    make_request "$url" "$body" 5000
}

# 获取路由参数
sender.getRouteParams() {
    local url="/getRouteParams"
    local body='{"senderid":"'${sender[senderid]}'"}'
    make_request "$url" "$body" 5000
}

# 获取路由方法
sender.getRouteMethod() {
    local url="/getRouteMethod"
    local body='{"senderid":"'${sender[senderid]}'"}'
    make_request "$url" "$body" 5000
}

# 获取路由请求头
sender.getRouteHeaders() {
    local url="/getRouteHeaders"
    local body='{"senderid":"'${sender[senderid]}'"}'
    make_request "$url" "$body" 5000
}

# 获取路由请求cookies
sender.getRouteCookies() {
    local url="/getRouteCookies"
    local body='{"senderid":"'${sender[senderid]}'"}'
    make_request "$url" "$body" 5000
}

# 获取路由请求体
sender.getRouteBody() {
    local url="/getRouteBody"
    local body='{"senderid":"'${sender[senderid]}'"}'
    make_request "$url" "$body" 5000
}

# 发送者渠道
sender.getImtype() {
    local url="/getImtype"
    local body='{"senderid":"'${sender[senderid]}'"}'
    make_request "$url" "$body" 5000
}

# 获取用户id
sender.getUserID() {
    # 去除字符串两头的引号
    local url="/getUserID"
    local body='{"senderid":"'${sender[senderid]}'"}'
    local userid=$(make_request $url $body 5000)
    userid=${userid#\"}
    userid=${userid%\"}
    echo "$userid"
}
# 获取用户头像地址
sender.getUserAvatarUrl() {
    local url="/getUserAvatarUrl"
    local body='{"senderid":"'${sender[senderid]}'"}'
    make_request "$url" "$body" 5000
}
# 获取用户昵称
sender.getUserName() {
    local url="/getUserName"
    local body='{"senderid":"'${sender[senderid]}'"}'
    make_request "$url" "$body" 5000
}
# 获取群组id
sender.getChatID() {
    local url="/getChatID"
    local body='{"senderid":"'${sender[senderid]}'"}'
    make_request "$url" "$body" 5000
}
# 获取群组名称
sender.getGroupName() {
    local url="/getGroupName"
    local body='{"senderid":"'${sender[senderid]}'"}'
    make_request "$url" "$body" 5000
}
# 是否为管理员
sender.isAdmin() {
    local url="/isAdmin"
    local body='{"senderid":"'${sender[senderid]}'"}'
    make_request "$url" "$body" 5000
}
# 获取消息ID
sender.getMessageID() {
    local url="/getMessageID"
    local body='{"senderid":"'${sender[senderid]}'"}'
    make_request "$url" "$body" 5000
}
# 获取历史消息ids
sender.getHistoryMessageIDs() {
    local number=$1
    local url="/getHistory"
    local body='{"senderid":"'${sender[senderid]}'","number":'$number'}'
    make_request "$url" "$body" 5000
}
# 撤回消息
sender.recallMessage() {
    local msgid=$1
    local url="/recall"
    local body='{"senderid":"'${sender[senderid]}'","msgid":"'$msgid'"}'
    make_request "$url" "$body" 5000
}
# 模拟新消息输入，即将消息发送者的消息修改为新的内容，重新送往autMan内部处理
sender.breakIn(){
    local content=$1
    local url="/breakIn"
    local body='{"senderid":"'${sender[senderid]}'","msg":"'$content'"}'
    make_request "$url" "$body" 5000
}
# 获取匹配的文本参数
sender.param() {
    local index=$1
    local url="/getMatchedText"
    local body='{"senderid":"'${sender[senderid]}'","index":"'$index'"}'
    make_request "$url" "$body" 5000
}
# 回复消息
sender.reply() {
    local text=$1
    local url="/sendText"
    local body='{"senderid":"'${sender[senderid]}'","text":"'$text'"}'
    make_request "$url" "$body" 5000
}

sender.edit() {
    local text=$1
    local url="/editText"
    local body='{"senderid":"'${sender[senderid]}'","text":"'$text'"}'
    make_request "$url" "$body" 5000
}

# 回复markdown消息
sender.replyMarkdown() {
    local markdown=$1
    local url="/sendMarkdown"
    local body='{"senderid":"'${sender[senderid]}'","markdown":"'$markdown'"}'
    make_request "$url" "$body" 5000
}

# 回复图片消息
sender.replyImage() {
    local imageurl=$1
    local url="/sendImage"
    local body='{"senderid":"'${sender[senderid]}'","imageurl":"'$imageurl'"}'
    make_request "$url" "$body" 5000
}

# 回复语音消息
sender.replyVoice() {
    local voiceurl=$1
    local url="/sendVoice"
    local body='{"senderid":"'${sender[senderid]}'","voiceurl":"'$voiceurl'"}'
    make_request "$url" "$body" 5000
}
# 回复视频消息
sender.replyVideo() {
    local videourl=$1
    local url="/sendVideo"
    local body='{"senderid":"'${sender[senderid]}'","videourl":"'$videourl'"}'
    make_request "$url" "$body" 5000
}
# 等待用户输入
sender.listen() {
    local timeout=$1
    local url="/listen"
    local body='{"senderid":"'${sender[senderid]}'","timeout":"'$timeout'"}'
    make_request "$url" "$body" 5000
}
# 等待用户输入,timeout为超时时间，单位为毫秒,recallDuration为撤回用户输入的延迟时间，单位为毫秒，0是不撤回，forGroup为bool值true或false，是否接收群聊所有成员的输入
sender.input() {
    local timeout=$1
    local recallDuration=$2
    local forGroup=$3
    local url="/input"
    local body='{"senderid":"'${sender[senderid]}'","timeout":"'$timeout'","recallDuration":"'$recallDuration'","forGroup":"'$forGroup'"}'
    make_request "$url" "$body" 5000
}
# 等待用户支付
sender.waitPay() {
    local exitcode=$1
    local timeout=$2
    local url="/waitPay"
    local body='{"senderid":"'${sender[senderid]}'","exitcode":"'$exitcode'","timeout":"'$timeout'"}'
    make_request "$url" "$body" 5000
}
# 是否处于等待支付状态
sender.atWaitingPay() {
   local url="/atWaitingPay"
   local body=''
   make_request "$url" "$body" 5000
}

# 邀请入群
sender.groupInviteIn() {
    local friend=$1
    local group=$2
    local url="/groupInviteIn"
    local body='{"senderid":"'${sender[senderid]}'","friend":"'$friend'","group":"'$group'"}'
    make_request "$url" "$body" 5000
}

# 踢出群组
sender.groupKick() {
    local userid=$1
    local url="/groupKick"
    local body='{"senderid":"'${sender[senderid]}'","userid":"'$userid'"}'
    make_request "$url" "$body" 5000
}

# 禁言
sender.groupBan() {
    local userid=$1
    local time=$2
    local url="/groupBan"
    local body='{"senderid":"'${sender[senderid]}'","userid":"'$userid'","time":"'$time'"}'
    make_request "$url" "$body" 5000
}

# 解除禁言
sender.groupUnban() {
    local userid=$1
    local url="/groupUnban"
    local body='{"senderid":"'${sender[senderid]}'","userid":"'$userid'"}'
    make_request "$url" "$body" 5000
}

# 全员禁言
sender.groupWholeBan() {
    local url="/groupWholeBan"
    local body='{"senderid":"'${sender[senderid]}'","time":"'$time'"}'
    make_request "$url" "$body" 5000
}

# 解除全员禁言
sender.groupWholeUnban() {
    local url="/groupWholeUnban"
    local body='{"senderid":"'${sender[senderid]}'"}'
    make_request "$url" "$body" 5000
}

# 发送群公告
sender.groupNoticeSend(){
    notice=$1
    local url="/groupNoticeSend"
    local body='{"senderid":"'${sender[senderid]}'","notice":"'$notice'"}'
    make_request "$url" "$body" 5000
}

# 获取当前处理流程的插件名
sender.getPluginName(){
    local url="/getPluginName"
    local body='{"senderid":"'${sender[senderid]}'"}'
    make_request "$url" "$body" 5000
}

# 获取当前处理流程的插件版本
sender.getPluginVersion(){
    local url="/getPluginVersion"
    local body='{"senderid":"'${sender[senderid]}'"}'
    make_request "$url" "$body" 5000
}

declare -A cron

# 获取定时指令集合
cron.getCrons() {
    local url="/croncmdsGet"
    make_request "$url" "$body" 5000
}

# 获取定时指令
cron.getCron() {
    local id=$1
    local url="/croncmdsGet"
    local body='{"id":"'$id'"}'
    make_request "$url" "$body" 5000
}

# 添加定时指令
cron.addCron() {
    local cron=$1
    local cmd=$2
    local isToSelf=$3
    local toOthers=$4
    local memo=$5
    local url="/croncmdsAdd"
    local body='{"cron":"'$cron'","cmd":"'$cmd'","isToSelf":"'$isToSelf'","toOthers":"'$toOthers'","memo":"'$memo'"}'
    make_request "$url" "$body" 5000
}

# 修改定时指令
cron.updateCron(){
    local id=$1
    local cron=$2
    local cmd=$3
    local isToSelf=$4
    local toOthers=$5
    local memo=$6
    local url="/croncmdsUpd"
    local body='{"id":"'$id'","cron":"'$cron'","cmd":"'$cmd'","isToSelf":"'$isToSelf'","toOthers":"'$toOthers'","memo":"'$memo'"}'
    make_request "$url" "$body" 5000
}

# 删除定时指令
cron.deleteCron(){
    local id=$1
    local url="/croncmdsDel"
    local body='{"id":"'$id'"}'
    make_request "$url" "$body" 5000
}

