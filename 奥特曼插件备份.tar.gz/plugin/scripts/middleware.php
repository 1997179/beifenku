<?php
//本地服务请求函数，返回请求结果
function fetchLocalURL($path,$body, $timeout) {
    $url="http://localhost:8080/otto$path";
    echo $url;

    // 初始化 cURL 会话
    $ch = curl_init();

    //设置请求地址
    curl_setopt($ch, CURLOPT_URL, $url);

    //设置为POST请求
    curl_setopt($ch, CURLOPT_POST, true);
    
    // 设置请求头
    $headers = array(
        "Content-Type: application/json",
    );
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    //设置请求体
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);//不直接输出到页面
    curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);//设置超时时间

    // 执行 cURL 会话
    $response = curl_exec($ch);
    echo $response;
    if ($response === false) {//处理错误
        $error = curl_error($ch);
        curl_close($ch);
        return "请求失败: " . $error;
    } else {//处理响应数据
        curl_close($ch);
        $resp=json_decode($response);
        if (isset($resp->data)){
            return $resp->data;
        }else{
            return NULL;
        }
    }
}

/**添加消息监听
 * @param $imtype string 消息类型
 * @param $chatid string 群聊ID
 * @param $userid string 用户ID
 * @param $callback function 回调函数
 * */ 
function addMsgListener($imtype,$chatid,$userid, $callback) {
    $url = "http://localhost:8080/otto/msghook";
    $data = json_encode(['imtype' => $imtype, 'chatid' => $chatid,"userid"=>$userid]);  // 将数据转换为JSON格式

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

    $response = curl_exec($ch);
    curl_close($ch);

    if ($response !== false) {
        // 建立SSE连接
        $source = new EventSource($url);
        $source->addEventListener('message', function ($event) use ($callback) {
            $callback($event->data);
        });
    }
}

// 推送消息
function push($imType,$groupCode,$userID,$title,$content){
    $path = "/push";
    $body=[
        "imType"=>$imType,
        "groupCode"=>$groupCode,
        "userID"=>$userID,
        "title"=>$title,
        "content"=>$content,
        ];
    return fetchLocalURL($path,$body, 5); 
}

// 获取autMan名称
function name(){
    $path = "/name";
    return fetchLocalURL($path,[], 5); 
}

// 获取autMan版本
function version(){
    $path = "/version";
    return fetchLocalURL($path,[], 5); 
}

// 获取数据库数据
function get($key){
    $path = "/get";
    $body = [
        "key"=>$key,
    ];
    return fetchLocalURL($path,$body, 5); 
}

// 设置数据库数据
function set($key,$value){
    $path = "/set";
    $body = [
        "key"=>$key,
        "value"=>$value,
        ];
    return fetchLocalURL($path,$body, 5); 
}

// 删除数据库数据
function del($key){
    $path = "/del";
    $body=[
        "key"=>$key
    ];
    return fetchLocalURL($path,$body, 5); 
}

// 获取指定数据库指定的key的值
function bucketGet($bucket,$key){
    $path = "/bucket/get";
    $body=[
        "bucket"=>$bucket,
        "key"=>$key,
    ];
    return fetchLocalURL($path,$body, 5); 
}

// 设置指定数据库指定的key的值
function bucketSet($bucket,$key,$value){
    $path = "/bucket/set";
    $body=[
        "bucket"=>$bucket,
        "key"=>$key,
        "value"=>$value,
    ];
    return fetchLocalURL($path,$body, 5); 
}

// 删除指定数据库指定的key的值
function bucketDel($bucket,$key){
    $path = "/bucketDel";
    $body=[
        "bucket"=>$bucket,
        "key"=>$key,
    ];
    return fetchLocalURL($path,$body, 5); 
}

// 获取指定数据库的所有值为value的keys
function bucketKeys($bucket,$value){
    $path = "/bucketKeys";
    $body=[
        "bucket"=>$bucket,
        "value"=>$value,
    ];
    $keys= fetchLocalURL($path,$body, 5); 
    return explode(",",$keys);
}

// 获取指定数据桶内所有key的集合
function bucketAllKeys($bucket){
    $path = "/bucketAllKeys";
    $body=[
        "bucket"=>$bucket,
    ];
    $keys= fetchLocalURL($path,$body, 5); 
    return explode(",",$keys);
}

// 通知管理员
function notifyMasters($content,$imtypes = []){
    $path = "/notifyMasters";
    $body=[
        "content"=>$content,
        "imtypes"=>$imtypes,
    ];
    return fetchLocalURL($path,$body, 5); 
}

// 系统咖啡码授权状态
function coffee(){
    $path = "/coffee";
    $body=[];
    return fetchLocalURL($path,$body, 5); 
}

//京东淘宝拼多多等转链推广
function spread($msg){
    $path = "/spread";
    $body=[
        "msg"=>$msg,
    ];
    return fetchLocalURL($path,$body, 5); 
}

class Sender{
    // 发送者ID 成员变量
    public $senderID;

    public function __construct($senderid){
        $this->senderID = $senderid;
    }

    // 获取指定数据库指定的key的值
    public function bucketGet($bucket,$key){
        $path = "/bucket/get";
        $body=[
            "senderid"=>$this->senderID,
            "bucket"=>$bucket,
            "key"=>$key,
        ];
        return fetchLocalURL($path,$body, 5); 
    }

    // 设置指定数据库指定的key的值
    public function bucketSet($bucket,$key,$value){
        $path = "/bucket/set";
        $body=[
            "senderid"=>$this->senderID,
            "bucket"=>$bucket,
            "key"=>$key,
            "value"=>$value,
        ];
        return fetchLocalURL($path,$body, 5); 
    }

    // 删除指定数据库指定的key的值
    public function bucketDel($bucket,$key){
        $path = "/bucketDel";
        $body=[
            "senderid"=>$this->senderID,
            "bucket"=>$bucket,
            "key"=>$key,
        ];
        return fetchLocalURL($path,$body, 5); 
    }

    // 获取指定数据库的所有值为value的keys
    public function bucketKeys($bucket,$value){
        $path = "/bucketKeys";
        $body=[
            "senderid"=>$this->senderID,
            "bucket"=>$bucket,
            "value"=>$value,
        ];
        $keys= fetchLocalURL($path,$body, 5); 
        return explode(",",$keys);
    }

    // 获取指定数据桶内所有key的集合
    public function bucketAllKeys($bucket){
        $path = "/bucketAllKeys";
        $body=[
            "senderid"=>$this->senderID,
            "bucket"=>$bucket,
        ];
        $keys= fetchLocalURL($path,$body, 5); 
        return explode(",",$keys);
    }

    public function setContinue(){
        $path="/continue";
        $body=[
            "senderid"=>$this->senderID,
        ];
        return fetchLocalURL($path,$body, 5);
    }

    // 路由路径
    public function getRoutePath(){
        $path="/getRoutePath";
        $body=[
            "senderid"=>$this->senderID
        ];
        return fetchLocalURL($path,$body, 5);
    }
    // 路由参数
    public function getRouteParams(){
        $path="/getRouteParams";
        $body=[
            "senderid"=>$this->senderID,
        ];
        return fetchLocalURL($path,$body, 5);
    }
    // 路由方法
    public function getRouteMethod(){
        $path="/getRouteMethod";
        $body=[
            "senderid"=>$this->senderID,
        ];
        return fetchLocalURL($path,$body, 5);
    }
    // 路由请求头
    public function getRouteHeaders(){
        $path="/getRouteHeaders";
        $body=[
            "senderid"=>$this->senderID,
        ];
        return fetchLocalURL($path,$body, 5);
    }
    // 路由请求cookies
    public function getRouteCookies(){
        $path="/getRouteCookies";
        $body=[
            "senderid"=>$this->senderID,
        ];
        return fetchLocalURL($path,$body, 5);
    }
    // 路由请求体
    public function getRouteBody(){
        $path="/getRouteBody";
        $body=[
            "senderid"=>$this->senderID,
        ];
        return fetchLocalURL($path,$body, 5);
    }
    // 获取发送者类型
    public function getImtype(){
        $path="/getImtype";
        $body=[
            "id"=>$this->id,
        ];
        return fetchLocalURL($path,$body, 5);
    }
    // 获取发送者ID
    public function getUserID(){
        $path="/getUserID";
        $body=[
            "senderid"=>$this->senderID,
        ];
        $userid=fetchLocalURL($path,$body, 5);
        //去掉两头的引号
        return $userid;
    }
    // 获取发送者名称
    public function getUserName(){
        $path="/getUserName";
        $body=[
            "senderid"=>$this->senderID,
        ];
        return fetchLocalURL($path,$body, 5);
    }
    // 获取发送者头像
    public function getUserAvatarUrl(){
        $path="/getUserAvatarUrl";
        $body=[
            "senderid"=>$this->senderID,
        ];
        return fetchLocalURL($path,$body, 5);
    }
    // 获取当前群组ID
    public function getChatID(){
        $path="/getChatID";
        $body=[
            "senderid"=>$this->senderID,
        ];
        return fetchLocalURL($path,$body, 5);
    }
    // 获取当前群组名称
    public function getChatName(){
        $path="/getChatName";
        $body=[
            "senderid"=>$this->senderID,
        ];
        return fetchLocalURL($path,$body, 5);
    }
    // 是否管理员
    public function isAdmin(){
        $path="/isAdmin";
        $body=[
            "senderid"=>$this->senderID,
        ];
        return fetchLocalURL($path,$body, 5);
    }
    // 获取消息id
    public function getMessageID(){
        $path="/getMessageID";
        $body=[
            "senderid"=>$this->senderID,
        ];
        return fetchLocalURL($path,$body, 5);
    }
    // 获取历史消息id
    public function getHistoryMessageIDs($number){
        $path="/getHistory";
        $body=[
            "senderid"=>$this->senderID,
            "number"=>$number,
        ];
        return fetchLocalURL($path,$body, 5);
    }
    // 撤回消息
    public function recallMessage($messageID){
        $path="/recallMessage";
        $body=[
            "senderid"=>$this->senderID,
            "id"=>$messageID,
        ];
        return fetchLocalURL($path,$body, 5);
    }
    // 模拟新消息输入，即将消息发送者的消息修改为新的内容，重新送往autMan内部处理
    public function breakIn($content){
        $path="/breakIn";
        $body=[
            "senderid"=>$this->senderID,
            "content"=>$content,
        ];
        return fetchLocalURL($path,$body, 5);
    }
    // 获取匹配的文本参数
    public function param($index){
        $path="/param";
        $body=[
            "senderid"=>$this->senderID,
            "index"=>$index,
        ];
        return fetchLocalURL($path,$body, 5);
    }
    // 回复文本消息
    public function reply($text){
        $path="/sendText";
        $body=[
            "senderid"=>$this->senderID,
            "text"=>$text,
        ];
        return fetchLocalURL($path,$body, 5);
    }
    //编辑消息
    public function edit($text){
        $path="/editText";
        $body=[
            "senderid"=>$this->senderID,
            "text"=>$text,
        ];
        return fetchLocalURL($path,$body, 5);
    }
    // 回复markdown消息
    public function replyMarkdown($markdown){
        $path="/sendMarkdown";
        $body=[
            "senderid"=>$this->senderID,
            "markdown"=>$markdown,
        ];
        return fetchLocalURL($path,$body, 5);
    }
    // 回复图片消息 
    public function replyImage($imageUrl){
        $path="/sendImage";
        $body=[
            "senderid"=>$this->senderID,
            "imageurl"=>$imageUrl,
        ];
        return fetchLocalURL($path,$body, 5);
    }
    // 回复语音消息
    public function replyVoice($voiceUrl){
        $path="/sendVoice";
        $body=[
            "senderid"=>$this->senderID,
            "voiceurl"=>$voiceUrl,
        ];
        return fetchLocalURL($path,$body, 5);
    }
    // 回复视频消息 
    public function replyVideo($videoUrl){
        $path="/sendVideo";
        $body=[
            "senderid"=>$this->senderID,
            "videourl"=>$videoUrl,
        ];
        return fetchLocalURL($path,$body, 5);
    }
    // 等待用户输入
    public function listen($timeout){
        $path="/listen";
        $body=[
            "senderid"=>$this->senderID,
            "timeout"=>$timeout,
        ];
        $response= fetchLocalURL($path,$body, $timeout/1000);
        //返回response的文本部分
        return $response;
    }
    // 等待用户输入,timeout为超时时间，单位为毫秒,recallDuration为撤回用户输入的延迟时间，单位为毫秒，0是不撤回，forGroup为bool值true或false，是否接收群聊所有成员的输入
    public function input($timeout,$recallDuration,$forGroup){
        $path="/input";
        $body=[
            "senderid"=>$this->senderID,
            "timeout"=>$timeout,
            "recallDuration"=>$recallDuration,
            "forGroup"=>$forGroup,
        ];
        $response= fetchLocalURL($path,$body, 5);
        //返回response的文本部分
        echo $response;
        return $response;
    }
    
    // 等待支付
    public function waitPay($exitcode,$timeout){
        $path="/waitPay";
        $body=[
            "senderid"=>$this->senderID,
            "exitcode"=>$exitcode,
            "timeout"=>$timeout,
        ];
        $response= fetchLocalURL($path,$body, 5);
        //返回response的文本部分
        echo $response;
        return $response;
    }
    // 是否处于等待支付状态
    public function atWaitPay(){
        $path="/atWaitPay";
        $body=[];
        return fetchLocalURL($path,$body, 5);
    }
    // 添加好友至群聊
    public function groupInviteIn($friendID,$groupID){
        $path="/groupInviteIn";$body=[
            "senderid"=>$this->senderID,
            "friendid"=>$friendID,
            "groupid"=>$groupID,
        ];
        return fetchLocalURL($path,$body, 5);
    }
    // 从群聊中移除好友
    public function groupKick($userid){
        $path="/groupKick";$body=[
            "senderid"=>$this->senderID,
            "userid"=>$userid,
        ];
        return fetchLocalURL($path,$body, 5);
    }
    // 群聊禁言
    public function groupBan($userid,$time){
        $path="/groupBan";$body=[
            "senderid"=>$this->senderID,
            "userid"=>$userid,
            "time"=>$time,
        ];
        return fetchLocalURL($path,$body, 5);
    }
    // 群聊解除禁言
    public function groupUnban($userid){
        $path="/groupUnban";$body=[
            "senderid"=>$this->senderID,
            "userid"=>$userid,
        ];
        return fetchLocalURL($path,$body, 5);
    }
    // 全员禁言
    public function groupWholeBan($time){
        $path="/groupWholeBan";$body=[
            "senderid"=>$this->senderID,
            "time"=>$time,
        ];
        return fetchLocalURL($path,$body, 5);
    }

    // 全员解除禁言
    public function groupWholeUnban(){
        $path="/groupWholeUnban";
        $body=[
            "senderid"=>$this->senderID,
        ];
        return fetchLocalURL($path,$body, 5);
    }

    // 发送群公告
    public function groupNoticeSend($notice){
        $path="/groupNoticeSend";
        $body=[
            "senderid"=>$this->senderID,
            "notice"=>$notice,
        ];
        return fetchLocalURL($path,$body, 5);
    }

    // 获取当前处理流程的插件名
    public function getPluginName(){
        $path="/getPluginName";
        $body=[
            "senderid"=>$this->senderID,
        ];
        return fetchLocalURL($path,$body, 5);
    }
    // 获取当前处理流程的插件版本
    public function getPluginVersion(){
        $path="/getPluginVersion";
        $body=[
            "senderid"=>$this->senderID,
        ];
        return fetchLocalURL($path,$body, 5);
    }
}

class Cron{
    // 获取定时指令集合
    public function getCrons(){
        $path="/croncmdsGet";
        $body=[];
        return fetchLocalURL($path,$body, 5);
    }
    //获取某个定时指令
    public function getCron($id){
        $path="/croncmdsGet";
        $body=[
            "id"=>$id,
        ];
        return fetchLocalURL($path,$body, 5);
    }
    // 添加定时指令，返回id
    public function addCron($cron,$cmd,$isToSelf,$toOthers,$memo){
        $path="/croncmdsAdd";
        $body=[
            "cron"=>$cron,
            "cmd"=>$cmd,
            "isToSelf"=>$isToSelf,
            "toOthers"=>$toOthers,
            "memo"=>$memo,
        ];
        return fetchLocalURL($path,$body, 5);
    }
    // 修改定时指令
    public function updateCron($id,$cron,$cmd,$isToSelf,$toOthers,$memo){
        $path="/croncmdsUpd";
        $body=[
            "id"=>$id,
            "cron"=>$cron,
            "cmd"=>$cmd,
            "isToSelf"=>$isToSelf,
            "toOthers"=>$toOthers,
            "memo"=>$memo,
        ];
        return fetchLocalURL($path,$body, 5);
    }
    // 删除定时指令
    public function deleteCron($id){
        $path="/croncmdsDel";
        $body=[
            "id"=>$id,
        ];
        return fetchLocalURL($path,$body, 5);
    }
}
?>